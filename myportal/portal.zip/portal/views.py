from __future__ import unicode_literals
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from . models import *
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from djgeojson.views import GeoJSONLayerView
from django.db.models import Sum

def index(request):

	# `ld=aa.event_date_field.replace("'" , ""))
		
	return render(request, 'dashboard.html')

def individualsreport(request):
	return render(request, 'individualsreport.html')

def cooperatereport(request):
	return render(request, 'cooperatereport.html')

def associationreport(request):
	return render(request, 'associationreport.html')




	

def report(request):
	return render(request, 'report.html')

def coperate(request):
	return render(request, 'managers_details.html')

def coperate2(request):
	return render(request, 'business_details.html')  

def firms(request):
	return render(request, 'firm_details.html')

def individuals(request):
	return render(request, 'individual_details.html')

def map(request):
	return render(request, 'map.html')


def vcard(request):
	return render(request, 'coperate.html')


def summaryView(request):

	posarr=[]
	sellinarr=[]
	evdarr=[]
	terrarr=[]
	yesarr=[]
	noarr=[]
	momoarr=[]

	if request.GET.get("startdate") and request.GET.get("enddate"):

		terr=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ,event_date_field__lte=request.GET.get("enddate") ).distinct("territory_id").order_by("territory_id")

		tltmomo=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ,event_date_field__lte=request.GET.get("enddate")).aggregate(Sum('momo_amount'))["momo_amount__sum"]

		tltevd=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ,event_date_field__lte=request.GET.get("enddate")).aggregate(Sum('evd_amount'))["evd_amount__sum"]

		tltuser=len(Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ,event_date_field__lte=request.GET.get("enddate")).distinct("user_id"))

		tlstatus=Training4326.objects.filter(status="Active (Open)",event_date_field__gte=request.GET.get("startdate") ,event_date_field__lte=request.GET.get("enddate")).distinct("user_id").count()


	elif  request.GET.get("startdate"):
		terr=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ).distinct("territory_id").order_by("territory_id")

		tltmomo=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ).aggregate(Sum('momo_amount'))["momo_amount__sum"]

		tltevd=Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ).aggregate(Sum('evd_amount'))["evd_amount__sum"]

		tltuser=len(Training4326.objects.filter(event_date_field__gte=request.GET.get("startdate") ).distinct("user_id"))

		tlstatus=Training4326.objects.filter(status="Active (Open)",event_date_field__gte=request.GET.get("startdate")).distinct("user_id").count()


	elif  request.GET.get("enddate"):
		terr=Training4326.objects.filter(event_date_field__lte=request.GET.get("enddate") ).distinct("territory_id").order_by("territory_id")

		tltmomo=Training4326.objects.filter(event_date_field__lte=request.GET.get("enddate")).aggregate(Sum('momo_amount'))["momo_amount__sum"]

		tltevd=Training4326.objects.filter(event_date_field__lte=request.GET.get("enddate")).aggregate(Sum('evd_amount'))["evd_amount__sum"]

		tltuser=len(Training4326.objects.filter(event_date_field__lte=request.GET.get("enddate")).distinct("user_id"))

		tlstatus=Training4326.objects.filter(status="Active (Open)",event_date_field__lte=request.GET.get("enddate")).distinct("user_id").count()


	else:

		terr=Training4326.objects.all().distinct("territory_id").order_by("territory_id")

		tltmomo=Training4326.objects.all().aggregate(Sum('momo_amount'))["momo_amount__sum"]

		tltevd=Training4326.objects.all().aggregate(Sum('evd_amount'))["evd_amount__sum"]

		tltuser=len(Training4326.objects.all().distinct("user_id"))

		tlstatus=Training4326.objects.filter(status="Active (Open)").distinct("user_id").count()


	

	for aa in terr:

		pos=Training4326.objects.filter(territory_id=aa.territory_id).count()

		yes=Training4326.objects.filter(territory_id=aa.territory_id , knowledge_of_selling_products=1).count()
		no=Training4326.objects.filter(territory_id=aa.territory_id , knowledge_of_selling_products=0).count()

		evd=Training4326.objects.filter(territory_id=aa.territory_id ).aggregate(Sum('evd_amount'))

		momo=Training4326.objects.filter(territory_id=aa.territory_id ).aggregate(Sum('momo_amount'))

		terrarr.append(aa.territory_id)
		posarr.append([aa.territory_id , pos])
		yesarr.append(yes)
		noarr.append(no)
		evdarr.append(checknone(evd["evd_amount__sum"]))
		momoarr.append(checknone(momo["momo_amount__sum"]))

	print(momoarr)
	print("helloo")
	users=Training4326.objects.all().distinct("pos_id")




	# print(posarr)
	# print(sellinarr)
	# print(evdarr)
	return render(request, 'summary.html',locals())



def posviews(request):

	users=Training4326.objects.filter(pos_id=request.GET.get("pos"))



	return render(request, 'posdetails.html',locals())







def dist_details(request):
	arr=[]
	distcode = request.GET.get("dist")
	county=County.objects.get(id=distcode)
	pos=Training4326.objects.filter(geom__within=county.geom).distinct("category")
	for aa in pos :
		poscount=Training4326.objects.filter(category= aa.category ,geom__within=county.geom).count()
		arr.append([aa.category,poscount])
	print(arr)
	return render(request, 'distdetails.html' , locals())


def heatmapView(request):
	arr=[]
	pos=Training4326.objects.all()
	for aa in pos :
		heat={}
		heat["lat"]=aa.latitude
		heat["lng"]=aa.longitude
		
		arr.append(heat)
	return JsonResponse(arr , safe = False)






def checknone(data):
	if data == None:
		return 0
	else:
		return data


class Training4326Layer(GeoJSONLayerView):
	# Options
	model = Training4326  #.objects.filter(region_new='GREATER ACCRA')
	precision = 3   
	simplify = 0.001
	properties = ('owner_first_name', 'owner_last_name', 'business_name', 'category', 'status')



class RegionLayer(GeoJSONLayerView):
	# Options
	model = RegDist  #.objects.filter(region_new='GREATER ACCRA')
	precision = 3   
	simplify = 0.001
	properties = ('name')


class countyLayer(GeoJSONLayerView):
	# Options
	model = Territories  #.objects.filter(region_new='GREATER ACCRA')
	precision = 3   
	simplify = 0.001
	properties = ('name')











