# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from django.contrib.gis.db import models
from django.contrib.gis.db.models import GeometryField
# Create your models here.


class Regions(models.Model):
    geom = models.GeometryField(blank=True, null=True)
    shape_leng = models.FloatField(blank=True, null=True)
    shape_area = models.FloatField(blank=True, null=True)
    adm1_en = models.CharField(max_length=50, blank=True, null=True)
    adm1_pcode = models.CharField(max_length=50, blank=True, null=True)
    adm1_ref = models.CharField(max_length=50, blank=True, null=True)
    adm1alt1en = models.CharField(max_length=50, blank=True, null=True)
    adm1alt2en = models.CharField(max_length=50, blank=True, null=True)
    adm0_en = models.CharField(max_length=50, blank=True, null=True)
    adm0_pcode = models.CharField(max_length=50, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    validon = models.DateField(blank=True, null=True)
    validto = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Regions'

class County(models.Model):
    geom = models.GeometryField(blank=True, null=True)
    shape_leng = models.FloatField(blank=True, null=True)
    shape_area = models.FloatField(blank=True, null=True)
    adm2_en = models.CharField(max_length=50, blank=True, null=True)
    adm2_pcode = models.CharField(max_length=50, blank=True, null=True)
    adm2_ref = models.CharField(max_length=50, blank=True, null=True)
    adm2alt1en = models.CharField(max_length=50, blank=True, null=True)
    adm2alt2en = models.CharField(max_length=50, blank=True, null=True)
    adm1_en = models.CharField(max_length=50, blank=True, null=True)
    adm1_pcode = models.CharField(max_length=50, blank=True, null=True)
    adm0_en = models.CharField(max_length=50, blank=True, null=True)
    adm0_pcode = models.CharField(max_length=50, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    validon = models.DateField(blank=True, null=True)
    validto = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'county'



class Training4326(models.Model):
    id = models.IntegerField(primary_key=True)
    geom = models.GeometryField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    pos_id = models.IntegerField(blank=True, null=True)
    knowledge_of_service = models.IntegerField(blank=True, null=True)
    knowledge_of_selling_products = models.IntegerField(blank=True, null=True)
    have_scratch_card = models.IntegerField(blank=True, null=True)
    have_evd = models.IntegerField(blank=True, null=True)
    data_package = models.IntegerField(blank=True, null=True)
    plug = models.IntegerField(blank=True, null=True)
    x5 = models.IntegerField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)
    latitude = models.FloatField(blank=True, null=True)
    distance = models.FloatField(blank=True, null=True)
    event_date = models.CharField(max_length=50, blank=True, null=True)
    event_date_field = models.DateTimeField(db_column='event_date_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    distince_field = models.CharField(db_column='distince_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    owner_first_name = models.CharField(max_length=50, blank=True, null=True)
    owner_last_name = models.CharField(max_length=50, blank=True, null=True)
    owner_telephone = models.IntegerField(blank=True, null=True)
    business_name = models.CharField(max_length=50, blank=True, null=True)
    category = models.CharField(max_length=50, blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)
    territory_id = models.IntegerField(blank=True, null=True)
    knowledge_of_selling_products_field = models.CharField(db_column='knowledge_of_selling_products_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    have_scratch_card_field = models.CharField(db_column='have_scratch_card_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    have_evd_field = models.CharField(db_column='have_evd_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    data_package_field = models.CharField(db_column='data_package_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    plug_field = models.CharField(db_column='plug_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    x5_field = models.CharField(db_column='x5_', max_length=50, blank=True, null=True)  # Field renamed because it ended with '_'.
    user_full_name = models.CharField(max_length=50, blank=True, null=True)
    user_telephone = models.IntegerField(blank=True, null=True)
    agent_msisdn = models.CharField(max_length=50, blank=True, null=True)
    balance_momo = models.IntegerField(blank=True, null=True)
    momo_amount = models.IntegerField(blank=True, null=True)
    did_top_up_evd = models.IntegerField(blank=True, null=True)
    evd_number = models.BigIntegerField(blank=True, null=True)
    evd_amount = models.FloatField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'Training4326'



class Territories(models.Model):
    geom = models.GeometryField(blank=True, null=True)
    name = models.CharField(db_column='Name', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    description = models.CharField(max_length=2000, blank=True, null=True)
    timestamp = models.DateTimeField(blank=True, null=True)
    begin = models.DateTimeField(blank=True, null=True)
    end = models.DateTimeField(blank=True, null=True)
    altitudemode = models.CharField(db_column='altitudeMode', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    tessellate = models.IntegerField(blank=True, null=True)
    extrude = models.IntegerField(blank=True, null=True)
    visibility = models.IntegerField(blank=True, null=True)
    draworder = models.IntegerField(db_column='drawOrder', blank=True, null=True)  # Field name made lowercase.
    icon = models.CharField(max_length=2000, blank=True, null=True)
    source = models.CharField(db_column='Source', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    descriptio = models.CharField(max_length=2000, blank=True, null=True)
    altitudemo = models.CharField(db_column='altitudeMo', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    county = models.CharField(db_column='COUNTY', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    tsc_name = models.CharField(db_column='TSC_Name', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    tsc_number = models.FloatField(db_column='TSC_Number', blank=True, null=True)  # Field name made lowercase.
    loc_rel = models.CharField(db_column='Loc_Rel', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    pos_count = models.FloatField(db_column='POS_Count', blank=True, null=True)  # Field name made lowercase.
    circuit_co = models.FloatField(db_column='Circuit_Co', blank=True, null=True)  # Field name made lowercase.
    cell_count = models.FloatField(db_column='Cell_Count', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'territories'





class RegDist(models.Model):
    geom = models.GeometryField(blank=True, null=True)
    name = models.CharField(db_column='Name', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    description = models.CharField(max_length=2000, blank=True, null=True)
    timestamp = models.DateTimeField(blank=True, null=True)
    begin = models.DateTimeField(blank=True, null=True)
    end = models.DateTimeField(blank=True, null=True)
    altitudemode = models.CharField(db_column='altitudeMode', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    tessellate = models.IntegerField(blank=True, null=True)
    extrude = models.IntegerField(blank=True, null=True)
    visibility = models.IntegerField(blank=True, null=True)
    draworder = models.IntegerField(db_column='drawOrder', blank=True, null=True)  # Field name made lowercase.
    icon = models.CharField(max_length=2000, blank=True, null=True)
    descriptio = models.CharField(max_length=2000, blank=True, null=True)
    altitudemo = models.CharField(db_column='altitudeMo', max_length=2000, blank=True, null=True)  # Field name made lowercase.
    circuit_co = models.FloatField(db_column='Circuit_Co', blank=True, null=True)  # Field name made lowercase.
    pos_count = models.FloatField(db_column='POS_Count', blank=True, null=True)  # Field name made lowercase.
    shape_leng = models.FloatField(db_column='Shape_Leng', blank=True, null=True)  # Field name made lowercase.
    shape_area = models.FloatField(db_column='Shape_Area', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Reg_Dist'








        
