from django.apps import AppConfig


class GbvConfig(AppConfig):
    name = 'gbv'
